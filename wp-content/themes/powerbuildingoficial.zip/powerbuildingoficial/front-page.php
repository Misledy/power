<?php  get_header(); ?>
<!-- ***********************SECTION BANNER*************************** -->
<?php  get_template_part('sections/banner'); ?>
<!-- ***********************SECTION POWERBUILDING-MASTHEAD*************************** -->
<?php  get_template_part('sections/powerbuilding-masthead'); ?>
<!-- ***********************SECTION BECOME-POWERBUILDER*************************** -->
<?php  get_template_part('sections/become-powerbuilder'); ?>
<!-- ***********************SECTION CUSTOMIZED-SERVICE*************************** -->
<?php  get_template_part('sections/customized-service'); ?>
<!-- ***********************SECTION TRAINERS*************************** -->
<?php  get_template_part('sections/trainers'); ?>
<!-- ***********************SECTION WORKMODE*************************** -->
<?php  get_template_part('sections/workmode'); ?>
<!-- ***********************SECTION TESTIMONIALS*************************** -->
<?php  get_template_part('sections/testimonials'); ?>
<!-- ***********************SECTION WE-ARE-A-MOVEMENT*************************** -->
<?php  get_template_part('sections/we-are-a-movement'); ?>
<!-- ***********************SECTION FAMOUS-ATHLETE-PROGRAMS*************************** -->
<?php  get_template_part('sections/famous-athlete-programs'); ?>
<!-- ***********************SECTION POWERBUILDING-OFICIAL-BLOG*************************** -->
<?php  get_template_part('sections/powerbuilding-oficial-blog'); ?>
<!-- ***********************END SECTION HOME*************************** -->
<?php  get_footer(); ?>