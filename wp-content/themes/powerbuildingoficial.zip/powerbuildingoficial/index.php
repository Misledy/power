<?php get_header(); ?>
<?php

echo "hola amigos!!";

?>

<?php get_footer(); ?>