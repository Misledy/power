<section id="we-are-a-movement">
      <div class="we-are-a-movement text-center">
        <div class="container">
          <div class="circle-brand">
            <img
              class="normalize-svg"
              src="<?php echo get_stylesheet_directory_uri() ?>/images/production/isotipe-powerbuilding-oficial.svg"
              alt=""
            />
          </div>
          <h2>SOMOS MÁS QUE UNA COMUNIDAD, SOMOS UN MOVIMIENTO. <br /></h2>
          <div class="btn-start">
            <a class="buttom-gradient-red">ÚNETE AL MOVIMIENTO</a>
          </div>
        </div>
      </div>
</section>