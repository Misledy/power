<section id="workmode">
      <div
        class="workmode"
        style="background-image: url(http://localhost:83/wp_site_powerbuilding/wp-content/themes/powerbuildingoficial/images/bk-workmode.png)"
      >
        <div class="container">
          <div class="row">
            <div class="col-md-6 col-md-offset-6">
              <div class="title-section text-left">
                <h2>
                  Tu transformación <br />
                  paso a paso
                </h2>
                <br />
                <img
                  class="icon-work-mode"
                  src="<?php echo get_stylesheet_directory_uri() ?>/images/services/icon-workmode-test.svg"
                  alt=""
                />
                <h5>Cuestionario para planificar tu entrenamiento y dieta.</h5>
                <br />
                <img
                  class="icon-work-mode"
                  src="<?php echo get_stylesheet_directory_uri() ?>/images/services/icon-workmode-whatsapp.svg"
                  alt=""
                />
                <h5>Seguimiento diario por tu entrenador vía WhatsApp.</h5>
                <br />
                <img
                  class="icon-work-mode"
                  src="<?php echo get_stylesheet_directory_uri() ?>/images/services/icon-workmode-skype.svg"
                  alt=""
                />
                <h5>Reunión con tu entrenador vía Skype.</h5>
                <div class="btn-start">
                  <a class="buttom-gradient-red">COMIENZA AHORA</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
</section>